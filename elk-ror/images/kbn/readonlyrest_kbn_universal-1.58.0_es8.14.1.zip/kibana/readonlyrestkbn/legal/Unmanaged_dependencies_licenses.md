# List of unmanaged dependencies and respective licenses

We use small parts of code taken from other projects whose license permit doing so. 
They are listed below.

##  Apache License 2.0
*  https://github.com/elastic/eui/tree/v34.6.0

