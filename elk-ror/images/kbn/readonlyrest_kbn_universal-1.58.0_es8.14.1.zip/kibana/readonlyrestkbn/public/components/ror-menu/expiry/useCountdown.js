"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.useCountdown = void 0;
const react_1 = require("react");
const useCountdown = (targetDate) => {
    const countDownDate = new Date(targetDate).getTime();
    const [countDown, setCountDown] = (0, react_1.useState)(countDownDate - new Date().getTime());
    (0, react_1.useEffect)(() => {
        let newDate;
        const interval = setInterval(() => {
            newDate = countDownDate - new Date().getTime();
            if (newDate < 0) {
                newDate = 0;
            }
            setCountDown(newDate);
        }, 1000);
        if (newDate === 0) {
            clearInterval(interval);
        }
        return () => clearInterval(interval);
    }, [countDownDate]);
    return countDown;
};
exports.useCountdown = useCountdown;
