"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Text = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function Text({ size = 'm', style, children, className }) {
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiText, { size: size, style: style, className: className, children: children }));
}
exports.Text = Text;
