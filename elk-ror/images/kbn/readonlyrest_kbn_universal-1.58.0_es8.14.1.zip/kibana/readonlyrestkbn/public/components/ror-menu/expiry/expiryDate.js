"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_1 = require("react");
const pretty_ms_1 = __importDefault(require("pretty-ms"));
const useCountdown_1 = require("./useCountdown");
function ExpiryDate({ validTo, handleTtlExpiry }) {
    const date = (0, useCountdown_1.useCountdown)(validTo);
    const humanReadableDate = (0, pretty_ms_1.default)(date, { secondsDecimalDigits: 0 });
    (0, react_1.useEffect)(() => {
        if (date === 0 && handleTtlExpiry) {
            handleTtlExpiry();
        }
    }, [date, handleTtlExpiry]);
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: humanReadableDate });
}
exports.default = ExpiryDate;
