"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FlexItem = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function FlexItem({ className, style, children, grow }) {
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiFlexItem, { className: className, style: style, grow: grow, children: children }));
}
exports.FlexItem = FlexItem;
