"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FlexGrid = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function FlexGrid({ gutterSize = 'l', columns = 0, children }) {
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiFlexGrid, { gutterSize: gutterSize, columns: columns, children: children }));
}
exports.FlexGrid = FlexGrid;
