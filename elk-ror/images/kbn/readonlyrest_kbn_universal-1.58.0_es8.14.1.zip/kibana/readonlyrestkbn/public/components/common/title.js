"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Title = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function Title({ children, size = 'xs' }) {
    return (0, jsx_runtime_1.jsx)(eui_1.EuiTitle, { size: size, children: children });
}
exports.Title = Title;
