"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ButtonEmpty = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function ButtonEmpty({ className, children, style, color = 'primary', textProps, contentProps, onClick, onMouseOver, onMouseLeave }) {
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiButtonEmpty
    // @ts-ignore
    , { 
        // @ts-ignore
        contentProps: contentProps, onMouseOver: onMouseOver, onMouseLeave: onMouseLeave, onClick: onClick, 
        // @ts-ignore
        textProps: textProps, color: color, 
        // @ts-ignore
        style: style, className: className, children: children }));
}
exports.ButtonEmpty = ButtonEmpty;
