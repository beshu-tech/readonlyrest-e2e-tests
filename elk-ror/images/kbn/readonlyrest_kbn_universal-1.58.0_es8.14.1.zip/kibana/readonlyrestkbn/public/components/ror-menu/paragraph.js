"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const text_1 = require("../common/text");
function Paragraph({ label, value, style, ...props }) {
    return ((0, jsx_runtime_1.jsx)(text_1.Text, { size: "s", style: style, children: (0, jsx_runtime_1.jsxs)("div", { ...props, style: { paddingBottom: '8px' }, children: [label, " ", (0, jsx_runtime_1.jsx)("span", { style: { fontWeight: 600 }, children: value })] }) }));
}
exports.default = Paragraph;
