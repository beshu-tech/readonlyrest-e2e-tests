"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * The Singleton class defines the `getInstance` method that lets clients access
 * the unique singleton instance.
 */
class CoreFunctions {
    core;
    static checkInitialization(core) {
        if (!core) {
            throw new Error('You need to initialized your class first');
        }
    }
    initialization(core) {
        this.core = core;
    }
    redirect(pathname) {
        CoreFunctions.checkInitialization(this.core);
        this.core.application.navigateToUrl(pathname);
    }
    /**
     * Prepend basePath and Include kibana space url namespace
     * @param pathname
     */
    basePathPrepend(pathname) {
        CoreFunctions.checkInitialization(this.core);
        return this.core.http.basePath.prepend(pathname);
    }
    /**
     * Prepend basePath and Ignore kibana space url namespace
     * @param pathname
     */
    serverBasePathPrepend(pathname) {
        CoreFunctions.checkInitialization(this.core);
        return `${this.serverBasePath}${pathname}`;
    }
    getSettingsParameter(parameter) {
        CoreFunctions.checkInitialization(this.core);
        return this.core.uiSettings.get(parameter);
    }
    /**
     * kibana basePath without space url namespace
     */
    get serverBasePath() {
        CoreFunctions.checkInitialization(this.core);
        return this.core.http.basePath.serverBasePath;
    }
    /**
     * kibana basePath with space url namespace
     */
    get basePath() {
        CoreFunctions.checkInitialization(this.core);
        return this.core.http.basePath.get();
    }
}
exports.default = new CoreFunctions();
